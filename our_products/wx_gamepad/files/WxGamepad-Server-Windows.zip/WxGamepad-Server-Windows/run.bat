@echo off
REM WxGamepad Server — Run script for Windows
REM Usage: run.bat [--port PORT]

cd /d "%~dp0"

REM Check Python
where python >nul 2>&1
if %errorlevel% neq 0 (
    echo Python 3 is required. Install from https://python.org
    pause
    exit /b 1
)

REM Create venv if needed
if not exist "venv" (
    echo Setting up virtual environment...
    python -m venv venv
    call venv\Scripts\activate.bat
    pip install -r requirements.txt
) else (
    call venv\Scripts\activate.bat
)

echo Starting WxGamepad Server...
python wxgamepad_server.py %*
pause
