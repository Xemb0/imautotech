#!/bin/bash
# WxGamepad Server — Run script for Mac/Linux
# Usage: ./run.sh [--port PORT]

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
cd "$SCRIPT_DIR"

# Check Python
if command -v python3 &> /dev/null; then
    PY=python3
elif command -v python &> /dev/null; then
    PY=python
else
    echo "Python 3 is required. Install from https://python.org"
    exit 1
fi

# Create venv if needed
if [ ! -d "venv" ]; then
    echo "Setting up virtual environment..."
    $PY -m venv venv
    source venv/bin/activate
    pip install -r requirements.txt
else
    source venv/bin/activate
fi

echo "Starting WxGamepad Server..."
python wxgamepad_server.py "$@"
