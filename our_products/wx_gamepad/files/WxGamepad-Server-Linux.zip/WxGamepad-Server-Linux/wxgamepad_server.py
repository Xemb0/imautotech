#!/usr/bin/env python3
"""
WxGamepad Desktop Server
Cross-platform server (Windows/Linux/Mac) that receives gamepad inputs
from the WxGamepad mobile app via WebSocket and simulates keyboard/mouse.

Usage:
    python wxgamepad_server.py [--port PORT]
"""

import argparse
import asyncio
import json
import signal
import socket
import sys
import threading
import time
from typing import Optional

try:
    import websockets
    from websockets.asyncio.server import serve
except ImportError:
    print("Missing dependency: websockets")
    print("Run: pip install websockets")
    sys.exit(1)

try:
    from pynput.keyboard import Controller as KeyboardController, Key
    from pynput.mouse import Controller as MouseController
except ImportError:
    print("Missing dependency: pynput")
    print("Run: pip install pynput")
    sys.exit(1)

# ---------------------------------------------------------------------------
# Key mapping: WxGamepad key strings → pynput Key objects
# ---------------------------------------------------------------------------

SPECIAL_KEYS = {
    "Enter": Key.enter,
    "enter": Key.enter,
    "Space": Key.space,
    "space": Key.space,
    "Backspace": Key.backspace,
    "backspace": Key.backspace,
    "Tab": Key.tab,
    "tab": Key.tab,
    "Escape": Key.esc,
    "escape": Key.esc,
    "Esc": Key.esc,
    "Shift": Key.shift,
    "shift": Key.shift,
    "Ctrl": Key.ctrl,
    "ctrl": Key.ctrl,
    "Control": Key.ctrl,
    "Alt": Key.alt,
    "alt": Key.alt,
    "CapsLock": Key.caps_lock,
    "capslock": Key.caps_lock,
    "Delete": Key.delete,
    "delete": Key.delete,
    "Home": Key.home,
    "End": Key.end,
    "PageUp": Key.page_up,
    "PageDown": Key.page_down,
    "Up": Key.up,
    "up": Key.up,
    "Down": Key.down,
    "down": Key.down,
    "Left": Key.left,
    "left": Key.left,
    "Right": Key.right,
    "right": Key.right,
    "F1": Key.f1, "F2": Key.f2, "F3": Key.f3, "F4": Key.f4,
    "F5": Key.f5, "F6": Key.f6, "F7": Key.f7, "F8": Key.f8,
    "F9": Key.f9, "F10": Key.f10, "F11": Key.f11, "F12": Key.f12,
}

# Add platform-specific keys that may not exist on all OSes
for _name, _attr in [("Insert", "insert"), ("insert", "insert")]:
    if hasattr(Key, _attr):
        SPECIAL_KEYS[_name] = getattr(Key, _attr)

# ---------------------------------------------------------------------------
# Input controller
# ---------------------------------------------------------------------------

class InputController:
    """Handles keyboard and mouse simulation."""

    def __init__(self):
        self.keyboard = KeyboardController()
        self.mouse = MouseController()
        self._pressed_keys: set = set()

    def press_key(self, key_str: str):
        """Press and hold a key."""
        if key_str in self._pressed_keys:
            return  # Already pressed
        self._pressed_keys.add(key_str)

        pynput_key = self._resolve_key(key_str)
        try:
            if isinstance(pynput_key, Key):
                self.keyboard.press(pynput_key)
            else:
                self.keyboard.press(pynput_key)
        except Exception:
            pass

    def release_key(self, key_str: str):
        """Release a held key."""
        self._pressed_keys.discard(key_str)

        pynput_key = self._resolve_key(key_str)
        try:
            if isinstance(pynput_key, Key):
                self.keyboard.release(pynput_key)
            else:
                self.keyboard.release(pynput_key)
        except Exception:
            pass

    def release_all(self):
        """Release all currently pressed keys."""
        for key_str in list(self._pressed_keys):
            self.release_key(key_str)

    def move_mouse(self, dx: float, dy: float):
        """Move mouse by relative amount."""
        self.mouse.move(int(dx), int(dy))

    def _resolve_key(self, key_str: str):
        """Convert a key string to a pynput key."""
        if key_str in SPECIAL_KEYS:
            return SPECIAL_KEYS[key_str]
        # Single character keys
        if len(key_str) == 1:
            return key_str.lower()
        # Unknown key — try as single char
        return key_str[0].lower() if key_str else "a"


# ---------------------------------------------------------------------------
# Network utilities
# ---------------------------------------------------------------------------

def get_local_ip() -> str:
    """Get the local network IP address."""
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("8.8.8.8", 80))
        ip = s.getsockname()[0]
        s.close()
        return ip
    except Exception:
        return "127.0.0.1"


def show_qr_code(ip: str, port: int):
    """Display QR code in terminal for easy mobile connection."""
    try:
        import qrcode
        qr = qrcode.QRCode(
            version=1,
            error_correction=qrcode.constants.ERROR_CORRECT_L,
            box_size=1,
            border=1,
        )
        qr.add_data(ip)
        qr.make(fit=True)

        # Print QR as ASCII
        matrix = qr.get_matrix()
        for row in matrix:
            line = ""
            for cell in row:
                line += "\u2588\u2588" if cell else "  "
            print(line)
    except ImportError:
        print(f"  (Install 'qrcode' package to show QR: pip install qrcode)")


# ---------------------------------------------------------------------------
# WebSocket server
# ---------------------------------------------------------------------------

class WxGamepadServer:
    """WebSocket server that handles WxGamepad connections."""

    def __init__(self, port: int = 3330):
        self.port = port
        self.controller = InputController()
        self.connected_clients: set = set()
        self._ping_tasks: dict = {}

    async def handler(self, websocket):
        """Handle a single WebSocket connection."""
        client_addr = websocket.remote_address
        self.connected_clients.add(websocket)
        print(f"\n  [+] Client connected: {client_addr[0]}:{client_addr[1]}")
        print(f"      Total clients: {len(self.connected_clients)}")

        # Start ping task for this client
        ping_task = asyncio.create_task(self._ping_loop(websocket))
        self._ping_tasks[websocket] = ping_task

        try:
            async for message in websocket:
                await self._process_message(message, websocket)
        except websockets.exceptions.ConnectionClosed:
            pass
        finally:
            self.connected_clients.discard(websocket)
            ping_task.cancel()
            self._ping_tasks.pop(websocket, None)
            self.controller.release_all()
            print(f"  [-] Client disconnected: {client_addr[0]}:{client_addr[1]}")
            print(f"      Total clients: {len(self.connected_clients)}")

    async def _ping_loop(self, websocket):
        """Send periodic PING messages to keep connection alive."""
        try:
            while True:
                await asyncio.sleep(15)
                try:
                    await websocket.send("PING")
                except Exception:
                    break
        except asyncio.CancelledError:
            pass

    async def _process_message(self, message: str, websocket):
        """Process an incoming message from the mobile app."""
        msg = message.strip()

        # Handshake
        if msg == "HSK":
            await websocket.send("HSK_DONE")
            return

        # Pong response (keepalive)
        if msg == "PONG":
            return

        # Key release: "-keyName"
        if msg.startswith("-"):
            key = msg[1:]
            if key:
                self.controller.release_key(key)
            return

        # Mouse movement: "mouse x y"
        if msg.startswith("mouse "):
            parts = msg.split()
            if len(parts) == 3:
                try:
                    dx = float(parts[1])
                    dy = float(parts[2])
                    self.controller.move_mouse(dx, dy)
                except ValueError:
                    pass
            return

        # Left joystick: "lj x y" → mapped to keys by the app already
        if msg.startswith("lj ") or msg.startswith("rj "):
            # Joystick position — the app maps these to key presses,
            # so these are informational only unless you want analog input
            return

        # Release joystick
        if msg in ("rlj", "rrj"):
            return

        # Regular key press
        if msg:
            self.controller.press_key(msg)

    async def start(self):
        """Start the WebSocket server."""
        ip = get_local_ip()

        print()
        print("  ╔══════════════════════════════════════════════╗")
        print("  ║          WxGamepad Desktop Server            ║")
        print("  ╠══════════════════════════════════════════════╣")
        print(f"  ║  IP Address : {ip:<31}║")
        print(f"  ║  Port       : {self.port:<31}║")
        print(f"  ║  Status     : {'Listening...':<31}║")
        print("  ╠══════════════════════════════════════════════╣")
        print("  ║  Scan QR or enter IP in WxGamepad app       ║")
        print("  ╚══════════════════════════════════════════════╝")
        print()
        print("  QR Code (scan with WxGamepad app):")
        print()
        show_qr_code(ip, self.port)
        print()
        print(f"  Waiting for connections on ws://{ip}:{self.port}/ws")
        print("  Press Ctrl+C to stop")
        print()

        async with serve(
            self.handler,
            "0.0.0.0",
            self.port,
        ) as server:
            await asyncio.Future()  # Run forever


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------

def main():
    parser = argparse.ArgumentParser(
        description="WxGamepad Desktop Server — receive gamepad inputs from your phone"
    )
    parser.add_argument(
        "--port", "-p",
        type=int,
        default=3330,
        help="Port to listen on (default: 3330)",
    )
    args = parser.parse_args()

    server = WxGamepadServer(port=args.port)

    try:
        asyncio.run(server.start())
    except KeyboardInterrupt:
        print("\n  Server stopped.")
        server.controller.release_all()


if __name__ == "__main__":
    main()
